const axios = require('axios')
const url = `https://taylor-swift-api.sarbo.workers.dev/albums`

const personaje  = async() =>{
    const taylor = await axios.get(url)
    let taylor_alb = taylor.data
    taylor_alb.forEach((album) => {
        console.log(album.title)
        console.log("--------")
    })

}

personaje()